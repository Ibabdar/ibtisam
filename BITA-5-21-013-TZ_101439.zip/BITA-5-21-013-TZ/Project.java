import java.util.Scanner;
public class Project extends Frame {
public static void main(String args[]) {
Login Log = new Login();
    }
}