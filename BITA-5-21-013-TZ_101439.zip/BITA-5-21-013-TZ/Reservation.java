import java.util.Scanner;
public class Reservation extends Frame implements ActionListener 
{
	Button b1,b2 b3;
	Label lab1,lab2;
	Reservation()
	{
		
		setLayout();
		b1=new Button("Check Availability");
		b2=new Button(" Create Passenger ");

		lab1= new Label("");
                lab2= new Label("");
		
		
                b1.addActionListener(this);
		b2.addActionListener(this);
		addWindowListener(new W());
	} 
	public void actionPerformed(ActionEvent AE) {
		if(AE.getSource())==b1 {
			
			Check m = new Check();
			m.setVisible(true);
			m.setTitle("Check Availability Screen");
		}
		if(AE.getSource())==b2 {
			Create v = new Create();
			v.setVisible(true);
			v.setTitle("Create Passenger Screen");
		}

}
	class W extends WindowAdapter {
		public void windowClosing(WindowEvent e) {
			setVisible(false);
			dispose();
			
		}
	}
}


