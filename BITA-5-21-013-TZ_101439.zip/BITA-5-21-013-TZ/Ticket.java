import java.util.Scanner;
public class Ticket extends Frame implements ActionListener {       
        Label l1;
        Button b1;
	Connection con;
	
	Ticket() {
        l1 = new Label("PNR NO ");
		b1.addActionListener(this);
       addWindowListener(new W());
}

		class W extends WindowAdapter {
		public void windowClosing(WindowEvent e) {
			setVisible(false);
			dispose();
			
		}
	}

}


