import java.util.Scanner;
public class Warning extends Frame {
	Button b1;
	Label l;
	 Warning() {
		setLayout();
		lab = new Label("Incorrect username or password",Label.CENTER);
		b1 = new Button("Ok");
		add(l);
		add(b1);
		
	b1.addActionListener(new Y());
	addWindowListener(new X());	
	}
	
	class Y implements ActionListener{
	public void actionPerformed(ActionEvent ae){
	if(ae.getSource()==b1){
	System.exit(0);
			}
		}
	}

	class X extends WindowAdapter {
		public void windowClosing(WindowEvent e) {
			setVisible(false);
			dispose();
		}
	}

	public Insets getInsets() {
		return new Insets(40,40,40,40);
	}
	
}




	


