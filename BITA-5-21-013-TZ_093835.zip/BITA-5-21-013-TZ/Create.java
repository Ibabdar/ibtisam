import java.util.Scanner;
public class Create extends Frame implements ActionListener {   
	Label lab1,lab2,lab3,lab4,lab5,lab6,lab7,lab8,lab9,lab10,lab11,lab12,lab13,lab14,lab15,lab16,lab17;
	Choice c;
	Button b1,b2,b3; 
	Connection con;
	
	Create() {
		setLayout();
		lab15 = new Label("Flight No");
		lab1 = new Label("Travel Date");
		lab2 = new Label("FName");
		lab3 = new Label("LName");
		lab4 = new Label("Age");
		lab5 = new Label("Gender");
		lab6 = new Label("Address");
		lab7 = new Label("Phone");
		lab8= new Label("Class");
		lab9= new Label("Status");
		
	c = new Choice();
		b1 = new Button("Submit");
		b2 = new Button("Reset");
        b3 = new Button("Generate Ticket");
	   
		lab10 = new Label("");
		lab11 = new Label("");
		lab12 = new Label("");
		lab13 = new Label("");
		lab14 = new Label("");
		
		c.add("DL - BGR : HA101");
		c.add("BGR - DL : HA102");
		c.add("DL - BY  : HA201");
		c.add("BY - DL  : HA202");
		c.add("DL - KLA : HA301");
		c.add("KLA - DL : HA302");
		c.add("DL - CHN : HA401");
		c.add("CHN - DL : HA402");
		c.add("DL - HYD : HA501");
		c.add("HYD - DL : HA502");
		c.add("DL - PUN : HA601");
		c.add("PUN - DL : HA602");
		
		 b1.addActionListener(this);
         b2.addActionListener(this);
		 addWindowListener(new W());
        
	}

	public void actionPerformed(ActionEvent ae) {
		if(ae.getSource()==b1) {
			try {   
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				con=DriverManager.getConnection("jdbc:odbc:MyDataSource1");
				ps=con.prepareStatement("insert into Passengers(FlightNo,TravelDate,FName,LName,Age,Gender,Address,Phone,Class,Status)values(?,?,?,?,?,?,?,?,?,?)");
			
	Ticket t = new Ticket();
		t.setVisible(true);
		t.setTitle("Ticket Screen");
		}
			catch(SQLException e){
				System.out.println("2 Error : "+e);
			}
			catch(Exception ex){
				System.out.println("Error 1:"+ex);
			}

		}
 }
	class W extends WindowAdapter {
		public void windowClosing(WindowEvent e) {
			setVisible(false);
			dispose();
			
		}
	}
	public static void main(String args[]) {
		Create v = new Create();
		v.setVisible(true);
		v.setTitle("Create Passenger Screen");
	}
}

