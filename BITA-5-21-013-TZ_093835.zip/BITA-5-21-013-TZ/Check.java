import java.util.Scanner;
public class Check extends Frame implements ActionListener 
{
	Label lab1,lab2,lab3,lab4,lab5,lab6,lab7,lab8,lab9,lab10,lab11,lab12;
		Check() {
		setLayout(gbl);
		lab1 = new Label("");
		lab4 = new Label("");
		lab5 = new Label("");
		lab6 = new Label("");
		lab7 = new Label("");
		lab2 = new Label("Travel Date");
		lab3 = new Label("Flight No");
		lab8 = new Label("First Class Seats");
		lab9 = new Label("Business Class Seats");
		lab10 = new Label("Economy Class Seats");
		lab11 = new Label("");
		lab12 = new Label("");
		
		c = new Choice();
		b1 = new Button("Submit");
		b2 = new Button("Reset");
		
		c.add("DL - BGR : HA101");
		c.add("BGR - DL : HA102");
		c.add("DL - BY  : HA201");
		c.add("BY - DL  : HA202");
		c.add("DL - KLA : HA301");
		c.add("KLA - DL : HA302");
		c.add("DL - CHN : HA401");
		c.add("CHN - DL : HA402");
		c.add("DL - HYD : HA501");
		c.add("HYD - DL : HA502");
		c.add("DL - PUN : HA601");
		c.add("PUN - DL : HA602");
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		addWindowListener(new W());
	    }
	public void actionPerformed(ActionEvent AE) {
		if(AE.getSource()==b1) {

			try {   
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				con=DriverManager.getConnection("jdbc:odbc:MyDataSource1");
				ps=con.prepareStatement("Select * from Reservation where TravelDate=? and FlightNo=?");
				ps.setString(1,t1.getText());
				ps.setString(2,t2.getText());
				rs=ps.executeQuery();
				rs.next();
				t3.setText(Integer.toString(rs.getInt(3)));
				t4.setText(Integer.toString(rs.getInt(4)));
		        t5.setText(Integer.toString(rs.getInt(5)));
                                con.close();
			}
			catch(Exception e) {
				System.out.println("2 Error : "+e);
			}
		}

		if(AE.getSource()==b2)
		
	}
	class W extends WindowAdapter {
		public void windowClosing(WindowEvent e) {
			setVisible(false);
			dispose();
			
		}
	}
}
