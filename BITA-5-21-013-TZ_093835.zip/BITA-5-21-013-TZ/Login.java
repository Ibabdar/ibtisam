import java.util.Scanner;
public class Login extends Frame implements ActionListener {
	String username = "iamavnish";
	String password = "sachin";
	
	public Login() {
	
		lab1 = new Label("Username",Label.CENTER);
		lab2= new Label("Password",Label.CENTER);
       
	
	}
}
